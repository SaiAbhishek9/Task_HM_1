﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Task_1_HM.Models;

   
namespace Task_1_HM.Controllers
{
   public class HomeController : Controller
    {
        List<SelectListItem> plist = new List<SelectListItem>();
        List<SelectListItem> alist = new List<SelectListItem>();

       public ActionResult Index()
        {
            return View();
        }

        [HttpPost]
        public ActionResult Index(LoginModel model)
        {
            if (ModelState.IsValid)
            {
                Task_1_DAL dal = new Task_1_DAL();
                dal.Login(model);
                return RedirectToAction("Welcome");
            }
            else
            {
                ViewBag.msg = "Invalid UserName or Password";
                return View();
            }
         }
        public ActionResult SignOut()
        {         
            return RedirectToAction("Index","Home");
        }
        public ActionResult Welcome()
        {
            return View();
        }
        public ActionResult Add_Maanger()
        {
            return View();
        }
        [HttpPost]
        public ActionResult Add_Manager(NewManagerModel model)
        {
            if (ModelState.IsValid)
            {       
                Task_1_DAL dal = new Task_1_DAL();
                dal.Add_Manager(model);
                ViewBag.msg = "Manager Added...";
                return View();
            }
            else
            {
                return View();
            }
        }
        public ActionResult Add_Project()
        {
            return View();
        }
        [HttpPost]
        public ActionResult Add_Project(NewProjectModel model)  
        {
            if (ModelState.IsValid)
            {
                Task_1_DAL dal = new Task_1_DAL();
                dal.Add_Project(model);
                ViewBag.msg = "Project Added...";
                return View();
            }
            else
            {
                return View();
            }
        }
        public ActionResult Add_Employee()
        {
            return View();
        }
        [HttpPost]
        public ActionResult Add_Employee(NewEmployeeModel model)
        {
            if (ModelState.IsValid)
            {
                Task_1_DAL dal = new Task_1_DAL();
                dal.Add_Employee(model);
                ViewBag.msg = "Employee Added...";
                return View();
            }
            else
            {
                return View();
            }
        }
        public ActionResult View_Projects()
        {
            Task_1_DAL dal = new Task_1_DAL();
            List<NewProjectModel> plist = dal.View_Projects();
            return View(plist);
        }
        public ActionResult View_Employees()
        {
            Task_1_DAL dal = new Task_1_DAL();
            List<NewEmployeeModel> elist = dal.View_Employees();
            return View(elist);
        }
        public ActionResult Allocate()
        {
            Task_1_DAL dal = new Task_1_DAL();
            List<SelectListItem> plist = dal.proj_drdw1();
            List<SelectListItem> alist = dal.proj_drdw2();
            ViewBag.plist = plist;
            ViewBag.alist = alist;
            return View();       
        }
              [HttpPost]
           public ActionResult Allocate(AllocateModel model)
        {
            if (ModelState.IsValid)
            {   
                Task_1_DAL dal = new Task_1_DAL();
                List<SelectListItem> plist = dal.proj_drdw1();
                List<SelectListItem> alist = dal.proj_drdw2();
                ViewBag.plist = plist;
                ViewBag.alist = alist;
                dal.Allocate_Projects(model);
                ViewBag.msg = "Project Allocated";      
                return View();
            }
            else
            {
                return View();
            }
        }
        public ActionResult View_Allocate()
        {      
            Task_1_DAL dal = new Task_1_DAL();
             List<AllocateModel> alist = dal.View_Allocate();
            return View(alist);
        }
        public ActionResult Dis_Allocate(int id)
        {
            Task_1_DAL dal = new Task_1_DAL();
            bool status = dal.Dis_Allocate(id);
            if (status)
            {
                ViewBag.msg = "Project Disallocated";
                return View("DisAllocated");
            }
            else
            {
                ViewBag.err = "Error Occurred";
                return View();
            }
        }
    }
}