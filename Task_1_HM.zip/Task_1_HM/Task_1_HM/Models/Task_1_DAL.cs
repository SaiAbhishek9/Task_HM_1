﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Collections;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Web.Mvc;

namespace Task_1_HM.Models
{
    public class Task_1_DAL
    {
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["constr"].ConnectionString);

        public void Login(LoginModel model)
        {
            try
            {
                con.Open();
                SqlCommand com_log = new SqlCommand("log_in", con);
                com_log.CommandType = CommandType.StoredProcedure;
                com_log.Parameters.AddWithValue("@email", model.LoginID);
                com_log.Parameters.AddWithValue("@password", model.Password);
                com_log.ExecuteReader();
            }
               
            finally
            {
                if (con.State == ConnectionState.Open)
                {
                    con.Close();

                }
            }
        }
              public void Add_Manager(NewManagerModel model)
        {
            try
            {
                con.Open();
                SqlCommand com_add = new SqlCommand("add_manager", con);
                com_add.CommandType = CommandType.StoredProcedure;
                com_add.Parameters.AddWithValue("@name", model.ManagerName);
                com_add.Parameters.AddWithValue("@email", model.ManagerEmail);
                com_add.Parameters.AddWithValue("@password", model.Password);
                com_add.ExecuteNonQuery();  
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                {
                    con.Close();
                }
            }
            }
        public void Add_Project(NewProjectModel model)
        {
            try
            {
                con.Open();
                SqlCommand com_add = new SqlCommand("add_project", con);
                com_add.CommandType = CommandType.StoredProcedure;
                com_add.Parameters.AddWithValue("@pname", model.ProjectName);
                com_add.Parameters.AddWithValue("@ptechnologies", model.ProjectTechnologies);
                com_add.Parameters.AddWithValue("@pduration", model.ProjectDuration);
                com_add.Parameters.AddWithValue("@pstartdate", model.ProjectStartDate);
                com_add.Parameters.AddWithValue("@penddate", model.ProjectEndDate);

                com_add.ExecuteNonQuery();

            }
            finally
            {
                if (con.State == ConnectionState.Open)
                {
                    con.Close();
                }
            }
            }
        public void Add_Employee(NewEmployeeModel model)
        {
            try
            {
                con.Open();
                SqlCommand com_add = new SqlCommand("add_employee", con);
                com_add.CommandType = CommandType.StoredProcedure;
                com_add.Parameters.AddWithValue("@name", model.EmployeeName);
                com_add.Parameters.AddWithValue("@experience", model.EmployeeExperience);
                com_add.Parameters.AddWithValue("@technologies", model.EmployeeTechnologies);
                com_add.Parameters.AddWithValue("@joiningdate", model.EmployeeJoiningDate);
                com_add.ExecuteNonQuery();
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                {
                    con.Close();
                }
            }
            }
        public void Allocate_Projects(AllocateModel model)
        {
            try
            {
                con.Open();
                SqlCommand com_all = new SqlCommand("allocate_proj", con);
                com_all.CommandType = CommandType.StoredProcedure;
                com_all.Parameters.AddWithValue("@mname", model.ManagerName);
                com_all.Parameters.AddWithValue("@pname", model.ProjectName);
                com_all.Parameters.AddWithValue("@eid", model.EmployeeID);
                com_all.ExecuteReader();      
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                {
                    con.Close();
                }
            }
            }
         public List<NewProjectModel> View_Projects()
        {
            try
            {
                con.Open();
                SqlCommand com_view = new SqlCommand("view_projects", con);
                com_view.CommandType = CommandType.StoredProcedure;
                List<NewProjectModel> plist = new List<NewProjectModel>();
                SqlDataReader dr = com_view.ExecuteReader();
                while (dr.Read())
                {
                    NewProjectModel np = new NewProjectModel();
                    np.ProjectID = dr.GetInt32(0);
                    np.ProjectName = dr.GetString(1);
                    np.ProjectTechnologies = dr.GetString(2);
                    np.ProjectDuration = dr.GetString(3);
                    np.ProjectStartDate = dr.GetDateTime(4);
                    np.ProjectEndDate = dr.GetDateTime(5);
                    plist.Add(np);
                }
                return plist;
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                {
                    con.Close();
                }
            }
            }
        public List<NewEmployeeModel> View_Employees()
        {
            try
            {
                con.Open();
                SqlCommand com_view = new SqlCommand("view_employees", con);
                com_view.CommandType = CommandType.StoredProcedure;
                List<NewEmployeeModel> elist = new List<NewEmployeeModel>();
                SqlDataReader dr = com_view.ExecuteReader();
                while (dr.Read())
                {
                    NewEmployeeModel em = new NewEmployeeModel();
                    em.EmployeeID = dr.GetInt32(0);
                    em.EmployeeName = dr.GetString(1);
                    em.EmployeeExperience = dr.GetString(2);
                    em.EmployeeTechnologies = dr.GetString(3);
                    em.EmployeeJoiningDate = dr.GetDateTime(4);
                    elist.Add(em);
                }
                return elist;
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                {
                    con.Close();
                }
            }
            }
        public List<AllocateModel> View_Allocate()
        {
            try
            {
                con.Open();
                SqlCommand com_view = new SqlCommand("view_allocprj", con);
                com_view.CommandType = CommandType.StoredProcedure;
                List<AllocateModel> alist = new List<AllocateModel>();
                SqlDataReader dr = com_view.ExecuteReader();
                while (dr.Read())
                {
                    AllocateModel model = new AllocateModel();
                    model.ManagerName = dr.GetString(0);
                    model.ProjectName = dr.GetString(1);
                    model.EmployeeID = dr.GetInt32(2);            
                    alist.Add(model);
                }
                return alist;
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                {
                    con.Close();
                }
            }
            }
        public bool Dis_Allocate(int id)
        {
            try
            {
                con.Open();
                SqlCommand com_dis = new SqlCommand("disallocate_proj", con);
                com_dis.CommandType = CommandType.StoredProcedure;
                com_dis.Parameters.AddWithValue("@id", id);
                int del = com_dis.ExecuteNonQuery();
                if (del > 0)
                {
                    return true;
                }
                else { return false; }
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                {
                    con.Close();
                }
            }
            }
        public List<SelectListItem> proj_drdw1()
        {
            try
            {
                con.Open();
                SqlCommand com_all = new SqlCommand("view_prjid", con);
                com_all.CommandType = CommandType.StoredProcedure;
                List<SelectListItem> plist = new List<SelectListItem>();    
                SqlDataReader dr = com_all.ExecuteReader();
                while (dr.Read())
                {
                  plist.Add(new SelectListItem { Text = dr["ProjectName"].ToString(), Value = dr["ProjectName"].ToString() });                
                }
                return plist;
            }   
            finally
            {
                if (con.State == ConnectionState.Open)
                {
                    con.Close();
                }
            }
        }
        public List<SelectListItem> proj_drdw2()
        {
            try
            {
                con.Open();
                SqlCommand com_all = new SqlCommand("view_emplid", con);
                com_all.CommandType = CommandType.StoredProcedure;
                List<SelectListItem> alist = new List<SelectListItem>();
                SqlDataReader dr = com_all.ExecuteReader();
                while (dr.Read())
                {
                    alist.Add(new SelectListItem { Text = dr["EmployeeID"].ToString(), Value = dr["EmployeeID"].ToString() });
                }
                return alist;
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                {
                    con.Close();
                }
            }
        }       
    }
    }
