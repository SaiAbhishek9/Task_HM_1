﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;

namespace Task_1_HM.Models
{
    public class NewProjectModel
    {   
        public int ProjectID { get; set; }

        [Required(ErrorMessage ="*")]
        [Display(Name ="Project Name : ")]
        [StringLength(100,ErrorMessage ="Max 100 chars")]
        public string ProjectName { get; set; }

        [Required(ErrorMessage ="*")]
        [Display(Name ="Project Technology : ")]
        public string ProjectTechnologies { get; set; }

        [Required(ErrorMessage ="*")]
        [Display(Name ="Project Duration : ")]
        public string ProjectDuration { get; set; }

        [Required(ErrorMessage ="*")]
        [Display(Name ="Project Start Date : ")]
        public DateTime ProjectStartDate { get; set; }

        [Required(ErrorMessage ="*")]
        [Display(Name ="Project End Date : ")]
        public DateTime ProjectEndDate { get; set; }
    }
}