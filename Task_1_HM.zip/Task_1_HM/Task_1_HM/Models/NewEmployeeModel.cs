﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;

namespace Task_1_HM.Models
{
    public class NewEmployeeModel
    {     
        public int EmployeeID { get; set; }

        [Required(ErrorMessage ="*")]
        [Display(Name ="Employee Name : ")]
        public string EmployeeName { get; set; }

        [Required(ErrorMessage ="*")]
        [Display(Name ="Employee Experience : ")]
        public string EmployeeExperience { get; set; }
        
        [Required(ErrorMessage ="*")]
        [Display(Name ="Employee Technologies : ")]
        public string EmployeeTechnologies { get; set; }

        [Required(ErrorMessage ="*")]
        [Display(Name ="Joining Date : ")]
        public DateTime EmployeeJoiningDate { get; set; }
    }
}