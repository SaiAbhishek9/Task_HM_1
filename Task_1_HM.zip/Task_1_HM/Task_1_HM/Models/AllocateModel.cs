﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;

namespace Task_1_HM.Models
{
    public class AllocateModel
    {
        [Required(ErrorMessage ="*")]
        [Display(Name ="Manager Name : ")]
        public string ManagerName { get; set; }

        [Required(ErrorMessage = "*")]
        [Display(Name = "Project Name : ")]
        public string ProjectName { get; set; }

        [Required(ErrorMessage = "*")]
        [Display(Name = "Employee ID : ")]
        public int EmployeeID { get; set; }

    }
}