﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;

namespace Task_1_HM.Models
{
    public class NewManagerModel
    {
        public int ManagerID { get; set; }

        [Required(ErrorMessage ="*")]
        [Display(Name ="Name : ")]
        [StringLength(100,ErrorMessage ="Max 100 chars")]
        public string ManagerName { get; set; }

        [Required(ErrorMessage ="*")]
        [Display(Name ="Email : ")]
        [EmailAddress(ErrorMessage ="Invalid_Format")]  
        public string ManagerEmail { get; set; }

        [Required(ErrorMessage ="*")]
        [Display(Name ="Password : ")]
        public string Password { get; set; }
    }
}